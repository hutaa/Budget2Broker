from fastapi import APIRouter, HTTPException, Query
from typing import Optional
import json
from app.schemas import (
    CompareRequest, CompareResponse, OptimizeRequest, OptimizeResponse,
    PredictSplitRequest, PredictSplitResponse, ExampleResponse
)
from app.services.recommend import compare_strategies, optimize_split_ratio
from app.models.load_model import get_predictor

router = APIRouter()

@router.get("/example", response_model=ExampleResponse)
async def get_example():
    """
    Get an example request/response pair for the frontend to use.
    """
    # Create a realistic example request
    example_request = CompareRequest(
        principal=30000,
        apr_annual=0.05,
        term_months=120,
        min_payment=318.20,
        extra_payment=200,
        monthly_contribution=100,
        split_ratio=0.5,
        start_savings=5000,
        expected_return_annual=0.07,
        volatility_annual=0.15,
        expense_ratio=0.001,
        tax_mode="taxable",
        horizon_years=10,
        sims=500,
        seed=42
    )
    
    # Generate response for the example request
    results = compare_strategies(
        principal=example_request.principal,
        apr_annual=example_request.apr_annual,
        term_months=example_request.term_months,
        min_payment=example_request.min_payment,
        extra_payment=example_request.extra_payment,
        monthly_contribution=example_request.monthly_contribution,
        split_ratio=example_request.split_ratio,
        start_savings=example_request.start_savings,
        expected_return_annual=example_request.expected_return_annual,
        volatility_annual=example_request.volatility_annual,
        expense_ratio=example_request.expense_ratio,
        tax_mode=example_request.tax_mode,
        horizon_years=example_request.horizon_years,
        sims=example_request.sims,
        seed=example_request.seed
    )
    
    # Create example response
    example_response = CompareResponse(
        strategies=results["strategies"],
        recommendation=results["recommendation"]
    )
    
    return ExampleResponse(
        request=example_request,
        response=example_response
    )

@router.post("/compare", response_model=CompareResponse)
async def compare_loan_vs_invest(request: CompareRequest):
    """
    Compare different strategies for loan repayment vs. investing.
    """
    try:
        results = compare_strategies(
            principal=request.principal,
            apr_annual=request.apr_annual,
            term_months=request.term_months,
            min_payment=request.min_payment,
            extra_payment=request.extra_payment,
            monthly_contribution=request.monthly_contribution,
            split_ratio=request.split_ratio,
            start_savings=request.start_savings,
            expected_return_annual=request.expected_return_annual,
            volatility_annual=request.volatility_annual,
            expense_ratio=request.expense_ratio,
            tax_mode=request.tax_mode,
            horizon_years=request.horizon_years,
            sims=request.sims,
            seed=request.seed
        )
        
        return CompareResponse(
            strategies=results["strategies"],
            recommendation=results["recommendation"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error comparing strategies: {str(e)}")

@router.post("/optimize", response_model=OptimizeResponse)
async def optimize_strategy(request: OptimizeRequest):
    """
    Optimize the split ratio between loan repayment and investing.
    """
    try:
        results = optimize_split_ratio(
            principal=request.principal,
            apr_annual=request.apr_annual,
            term_months=request.term_months,
            min_payment=request.min_payment,
            extra_payment=request.extra_payment,
            monthly_contribution=request.monthly_contribution,
            start_savings=request.start_savings,
            expected_return_annual=request.expected_return_annual,
            volatility_annual=request.volatility_annual,
            expense_ratio=request.expense_ratio,
            tax_mode=request.tax_mode,
            horizon_years=request.horizon_years,
            target_payoff_months=request.target_payoff_months,
            min_cash_buffer=request.min_cash_buffer,
            sims=request.sims,
            seed=request.seed
        )
        
        return OptimizeResponse(
            best_split_ratio=results["best_split_ratio"],
            objective_value=results["objective_value"],
            metrics=results["metrics"],
            sensitivity=results["sensitivity"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error optimizing strategy: {str(e)}")

@router.post("/predict_split", response_model=PredictSplitResponse)
async def predict_split_ratio(request: PredictSplitRequest):
    """
    Use ML model to predict optimal split ratio.
    """
    try:
        # Get predictor instance
        predictor = get_predictor()
        
        # Convert request to dictionary
        input_data = request.model_dump()
        
        # Make prediction
        prediction = predictor.predict_split(input_data)
        
        return PredictSplitResponse(
            predicted_split=prediction["predicted_split"],
            confidence=prediction["confidence"],
            top_features=prediction["top_features"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error predicting split ratio: {str(e)}")
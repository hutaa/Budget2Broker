import os
import pickle
import numpy as np
from typing import Dict, List, Tuple, Optional
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SplitPredictor:
    """
    Class to load and use the ML model for predicting optimal split ratio.
    """
    def __init__(self, model_path: str = "models/split_predictor.pkl"):
        """
        Initialize the predictor with a model path.
        
        Args:
            model_path: Path to the pickled model file
        """
        self.model = None
        self.model_path = model_path
        self.feature_names = [
            "principal", "apr_annual", "term_months", "min_payment", "extra_payment",
            "monthly_contribution", "start_savings", "expected_return_annual",
            "volatility_annual", "expense_ratio", "horizon_years", "tax_mode_numeric"
        ]
        self.load_model()
    
    def load_model(self) -> None:
        """
        Load the model from disk if it exists, otherwise create a simple fallback model.
        """
        try:
            if os.path.exists(self.model_path):
                with open(self.model_path, "rb") as f:
                    self.model = pickle.load(f)
                logger.info(f"Loaded model from {self.model_path}")
            else:
                logger.warning(f"Model file {self.model_path} not found. Using fallback model.")
                self._create_fallback_model()
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            self._create_fallback_model()
    
    def _create_fallback_model(self) -> None:
        """
        Create a simple fallback model based on heuristics.
        This is used when the trained model is not available.
        """
        # Simple class to mimic the predict method of ML models
        class FallbackModel:
            def predict(self, X):
                # Extract features from input
                apr_annual = X[:, 1]  # Index 1 corresponds to apr_annual
                expected_return = X[:, 7]  # Index 7 corresponds to expected_return_annual
                
                # Simple heuristic: split ratio based on difference between APR and expected return
                # If APR > expected_return + 2%, favor loan payoff (split_ratio close to 1)
                # If expected_return > APR + 2%, favor investment (split_ratio close to 0)
                # Otherwise, balanced approach (split_ratio around 0.5)
                
                split_ratios = np.zeros(X.shape[0])
                
                for i in range(X.shape[0]):
                    if apr_annual[i] > expected_return[i] + 0.02:
                        # Higher APR favors loan payoff
                        split_ratios[i] = 0.8
                    elif expected_return[i] > apr_annual[i] + 0.02:
                        # Higher expected return favors investment
                        split_ratios[i] = 0.2
                    else:
                        # Similar rates favor balanced approach
                        split_ratios[i] = 0.5
                
                return split_ratios
        
        self.model = FallbackModel()
        logger.info("Created fallback model")
    
    def preprocess_input(self, input_data: Dict) -> np.ndarray:
        """
        Preprocess input data for model prediction.
        
        Args:
            input_data: Dictionary with input features
        
        Returns:
            Numpy array with preprocessed features
        """
        # Convert categorical features to numeric
        tax_mode_numeric = 1 if input_data.get("tax_mode") == "tax_advantaged" else 0
        
        # Create feature array
        features = np.array([
            input_data.get("principal", 0),
            input_data.get("apr_annual", 0),
            input_data.get("term_months", 0),
            input_data.get("min_payment", 0),
            input_data.get("extra_payment", 0),
            input_data.get("monthly_contribution", 0),
            input_data.get("start_savings", 0),
            input_data.get("expected_return_annual", 0),
            input_data.get("volatility_annual", 0),
            input_data.get("expense_ratio", 0),
            input_data.get("horizon_years", 0),
            tax_mode_numeric
        ]).reshape(1, -1)
        
        return features
    
    def predict_split(self, input_data: Dict) -> Dict:
        """
        Predict the optimal split ratio based on input data.
        
        Args:
            input_data: Dictionary with input features
        
        Returns:
            Dictionary with prediction results
        """
        # Preprocess input
        features = self.preprocess_input(input_data)
        
        # Make prediction
        predicted_split = float(self.model.predict(features)[0])
        
        # Ensure prediction is within valid range [0, 1]
        predicted_split = max(0, min(1, predicted_split))
        
        # Calculate confidence (simplified approach)
        # For fallback model, confidence is based on how extreme the APR vs return difference is
        apr_annual = input_data.get("apr_annual", 0)
        expected_return = input_data.get("expected_return_annual", 0)
        rate_diff = abs(apr_annual - expected_return)
        
        # Higher difference means higher confidence
        confidence = min(0.9, rate_diff * 10)  # Cap at 0.9
        
        # If difference is small, confidence is lower
        if rate_diff < 0.01:
            confidence = 0.5
        
        # Get feature importances (simplified for fallback model)
        top_features = self._get_feature_importances(input_data)
        
        return {
            "predicted_split": predicted_split,
            "confidence": confidence,
            "top_features": top_features
        }
    
    def _get_feature_importances(self, input_data: Dict) -> List[Dict]:
        """
        Get feature importances for the prediction.
        
        Args:
            input_data: Dictionary with input features
        
        Returns:
            List of dictionaries with feature names and importances
        """
        # For the fallback model, use heuristic-based importances
        apr_annual = input_data.get("apr_annual", 0)
        expected_return = input_data.get("expected_return_annual", 0)
        
        if abs(apr_annual - expected_return) > 0.02:
            # If rates differ significantly, they are most important
            importances = [
                {"name": "apr_annual", "importance": 0.4},
                {"name": "expected_return_annual", "importance": 0.35},
                {"name": "term_months", "importance": 0.15},
                {"name": "extra_payment", "importance": 0.1}
            ]
        else:
            # If rates are similar, other factors matter more
            importances = [
                {"name": "extra_payment", "importance": 0.3},
                {"name": "apr_annual", "importance": 0.25},
                {"name": "expected_return_annual", "importance": 0.25},
                {"name": "volatility_annual", "importance": 0.2}
            ]
        
        return importances

# Singleton instance
_predictor = None

def get_predictor() -> SplitPredictor:
    """
    Get or create the predictor instance.
    
    Returns:
        SplitPredictor instance
    """
    global _predictor
    if _predictor is None:
        _predictor = SplitPredictor()
    return _predictor
import numpy as np
from typing import List, Tuple, Dict, Optional
from datetime import date, timedelta
import pandas as pd

def calculate_amortization(
    principal: float,
    apr_annual: float,
    term_months: int,
    payment: float,
    extra_payment: float = 0.0,
    max_months: int = 600
) -> Dict:
    """
    Calculate loan amortization schedule with optional extra payments.
    
    Args:
        principal: Initial loan amount
        apr_annual: Annual interest rate (decimal)
        term_months: Original loan term in months
        payment: Regular monthly payment amount
        extra_payment: Additional monthly payment
        max_months: Maximum months to calculate (cap at 50 years)
    
    Returns:
        Dictionary with amortization results including:
        - months_to_zero: Months until loan is paid off
        - total_interest: Total interest paid over life of loan
        - balance_series: Monthly balance time series
        - payoff_date: Estimated payoff date
    """
    # Monthly interest rate
    r_m = apr_annual / 12
    
    # Initialize variables
    balance = principal
    month = 0
    total_interest = 0
    balance_series = []
    
    # Store initial balance
    balance_series.append({"month": month, "value": balance})
    
    # Calculate amortization schedule
    while balance > 0 and month < max_months:
        month += 1
        
        # Calculate interest for this month
        interest = balance * r_m
        total_interest += interest
        
        # Calculate principal payment
        total_payment = payment + extra_payment
        principal_payment = total_payment - interest
        
        # Adjust principal payment if it would overpay the loan
        if principal_payment > balance:
            principal_payment = balance
            total_payment = principal_payment + interest
        
        # Update balance
        balance -= principal_payment
        
        # Store balance for this month
        balance_series.append({"month": month, "value": balance})
        
        # Break if balance is effectively zero
        if balance < 0.01:
            balance = 0
            break
    
    # Calculate payoff date
    today = date.today()
    if balance <= 0:
        payoff_date = (today + timedelta(days=30 * month)).isoformat()
    else:
        payoff_date = None
    
    return {
        "months_to_zero": month if balance <= 0 else None,
        "total_interest": total_interest,
        "balance_series": balance_series,
        "payoff_date": payoff_date
    }

def calculate_minimum_payment(principal: float, apr_annual: float, term_months: int) -> float:
    """
    Calculate the minimum monthly payment required to pay off a loan within the term.
    
    Args:
        principal: Initial loan amount
        apr_annual: Annual interest rate (decimal)
        term_months: Loan term in months
    
    Returns:
        Minimum monthly payment amount
    """
    # Monthly interest rate
    r_m = apr_annual / 12
    
    # If interest rate is effectively zero, simple division
    if apr_annual < 0.000001:
        return principal / term_months
    
    # Standard amortization formula
    payment = principal * r_m * (1 + r_m) ** term_months / ((1 + r_m) ** term_months - 1)
    
    return payment

def compare_payment_strategies(
    principal: float,
    apr_annual: float,
    term_months: int,
    min_payment: float,
    extra_payment: float,
    split_ratio: float = 0.5
) -> Dict:
    """
    Compare different payment strategies:
    1. Minimum payments only
    2. Extra payments to loan
    3. Minimum to loan, extra to investments
    4. Split extra between loan and investments
    
    Args:
        principal: Initial loan amount
        apr_annual: Annual interest rate (decimal)
        term_months: Original loan term in months
        min_payment: Minimum monthly payment amount
        extra_payment: Additional available monthly amount
        split_ratio: Portion of extra payment to put toward loan (0-1)
    
    Returns:
        Dictionary with results for each strategy
    """
    # Strategy 1: Minimum payments only
    min_only = calculate_amortization(
        principal=principal,
        apr_annual=apr_annual,
        term_months=term_months,
        payment=min_payment
    )
    
    # Strategy 2: All extra to loan
    extra_to_loan = calculate_amortization(
        principal=principal,
        apr_annual=apr_annual,
        term_months=term_months,
        payment=min_payment,
        extra_payment=extra_payment
    )
    
    # Strategy 3: Split extra between loan and investments
    loan_portion = extra_payment * split_ratio
    split_strategy = calculate_amortization(
        principal=principal,
        apr_annual=apr_annual,
        term_months=term_months,
        payment=min_payment,
        extra_payment=loan_portion
    )
    
    # Calculate interest saved for each strategy compared to minimum payments
    extra_to_loan["interest_saved"] = min_only["total_interest"] - extra_to_loan["total_interest"]
    split_strategy["interest_saved"] = min_only["total_interest"] - split_strategy["total_interest"]
    
    return {
        "min_only": min_only,
        "extra_to_loan": extra_to_loan,
        "split": split_strategy
    }
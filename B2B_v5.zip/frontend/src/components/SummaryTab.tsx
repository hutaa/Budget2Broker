import React from 'react';
import { CompareResponse } from '../lib/api';

interface SummaryTabProps {
  results: CompareResponse;
}

const SummaryTab: React.FC<SummaryTabProps> = ({ results }) => {
  const { strategies, recommendation } = results;
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  // Format date
  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
    });
  };
  
  // Get strategy display name
  const getStrategyName = (key: string) => {
    switch (key) {
      case 'pay_more': return 'Pay More on Loan';
      case 'invest_more': return 'Invest More';
      case 'split': return 'Split Approach';
      default: return key;
    }
  };

  return (
    <div>
      {/* Recommendation Card */}
      <div className={`mb-8 p-6 rounded-lg border-l-4 ${
        recommendation.strategy === 'pay_more' ? 'bg-success-50 border-success-500' :
        recommendation.strategy === 'invest_more' ? 'bg-primary-50 border-primary-500' :
        'bg-secondary-50 border-secondary-500'
      }`}>
        <h3 className="text-xl font-bold mb-2">
          Recommended Strategy: {getStrategyName(recommendation.strategy)}
        </h3>
        <p className="text-secondary-700 mb-4">{recommendation.rationale}</p>
        
        {recommendation.breakeven_month && (
          <div className="text-sm bg-white p-3 rounded border border-secondary-200">
            <span className="font-medium">Breakeven Point:</span> After {recommendation.breakeven_month} months, 
            the investment approach is projected to outperform the interest savings from extra loan payments.
          </div>
        )}
      </div>
      
      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {/* Debt-free Date */}
        <div className="kpi-card">
          <h4 className="kpi-title">Debt-free By</h4>
          <div className="kpi-value">
            {formatDate(strategies[recommendation.strategy].payoff_date)}
          </div>
          <p className="kpi-subtitle">
            {strategies[recommendation.strategy].months_to_zero 
              ? `${strategies[recommendation.strategy].months_to_zero} months` 
              : 'Beyond horizon'}
          </p>
        </div>
        
        {/* Total Interest */}
        <div className="kpi-card">
          <h4 className="kpi-title">Total Interest</h4>
          <div className="kpi-value">
            {formatCurrency(strategies[recommendation.strategy].total_interest)}
          </div>
          <p className="kpi-subtitle text-success-600">
            {strategies[recommendation.strategy].interest_saved_vs_min > 0 
              ? `Save ${formatCurrency(strategies[recommendation.strategy].interest_saved_vs_min)}` 
              : 'Minimum payments'}
          </p>
        </div>
        
        {/* Investment Value */}
        <div className="kpi-card">
          <h4 className="kpi-title">Investment Value (Median)</h4>
          <div className="kpi-value">
            {formatCurrency(strategies[recommendation.strategy].invested_value_p50)}
          </div>
          <p className="kpi-subtitle">
            Range: {formatCurrency(strategies[recommendation.strategy].invested_value_p10)} - {formatCurrency(strategies[recommendation.strategy].invested_value_p90)}
          </p>
        </div>
      </div>
      
      {/* Strategy Comparison Table */}
      <h3 className="text-lg font-semibold mb-4">Strategy Comparison</h3>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-secondary-200">
          <thead className="bg-secondary-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                Strategy
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                Payoff Date
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                Total Interest
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                Interest Saved
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                Investment Value
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-secondary-200">
            {Object.entries(strategies).map(([key, strategy]) => (
              <tr key={key} className={recommendation.strategy === key ? 'bg-secondary-50' : ''}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    {recommendation.strategy === key && (
                      <span className="flex-shrink-0 h-4 w-4 rounded-full bg-success-500 mr-2"></span>
                    )}
                    <div className="text-sm font-medium text-secondary-900">
                      {getStrategyName(key)}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                  {formatDate(strategy.payoff_date)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                  {formatCurrency(strategy.total_interest)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                  {formatCurrency(strategy.interest_saved_vs_min)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                  {formatCurrency(strategy.invested_value_p50)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Notes */}
      <div className="mt-8 text-sm text-secondary-600 bg-secondary-50 p-4 rounded">
        <h4 className="font-medium mb-2">Strategy Notes:</h4>
        <ul className="list-disc pl-5 space-y-1">
          {Object.entries(strategies).map(([key, strategy]) => (
            <li key={key}>
              <span className="font-medium">{getStrategyName(key)}:</span> {strategy.notes}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default SummaryTab;
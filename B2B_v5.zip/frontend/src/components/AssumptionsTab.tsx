import React from 'react';
import { CompareRequest } from '../lib/api';

interface AssumptionsTabProps {
  formData: CompareRequest;
}

const AssumptionsTab: React.FC<AssumptionsTabProps> = ({ formData }) => {
  // Format percentage
  const formatPercent = (value: number) => {
    return `${(value * 100).toFixed(2)}%`;
  };
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Model Assumptions</h3>
      
      {/* Loan Assumptions */}
      <div className="mb-8">
        <h4 className="text-md font-medium mb-3 pb-2 border-b border-secondary-200">Loan Parameters</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-secondary-600">Principal</p>
            <p className="font-medium">{formatCurrency(formData.principal)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Annual Interest Rate</p>
            <p className="font-medium">{formatPercent(formData.apr_annual)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Loan Term</p>
            <p className="font-medium">{formData.term_months} months ({(formData.term_months / 12).toFixed(1)} years)</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Minimum Monthly Payment</p>
            <p className="font-medium">{formatCurrency(formData.min_payment)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Extra Monthly Payment</p>
            <p className="font-medium">{formatCurrency(formData.extra_payment)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Split Ratio (Loan/Investment)</p>
            <p className="font-medium">{formatPercent(formData.split_ratio)} / {formatPercent(1 - formData.split_ratio)}</p>
          </div>
        </div>
      </div>
      
      {/* Investment Assumptions */}
      <div className="mb-8">
        <h4 className="text-md font-medium mb-3 pb-2 border-b border-secondary-200">Investment Parameters</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-secondary-600">Initial Investment</p>
            <p className="font-medium">{formatCurrency(formData.start_savings)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Monthly Contribution</p>
            <p className="font-medium">{formatCurrency(formData.monthly_contribution)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Expected Annual Return</p>
            <p className="font-medium">{formatPercent(formData.expected_return_annual)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Annual Volatility</p>
            <p className="font-medium">{formatPercent(formData.volatility_annual)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Expense Ratio</p>
            <p className="font-medium">{formatPercent(formData.expense_ratio)}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Tax Treatment</p>
            <p className="font-medium">{formData.tax_mode === 'taxable' ? 'Taxable Account' : 'Tax-Advantaged Account'}</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Planning Horizon</p>
            <p className="font-medium">{formData.horizon_years} years</p>
          </div>
          <div>
            <p className="text-sm text-secondary-600">Monte Carlo Simulations</p>
            <p className="font-medium">{formData.sims}</p>
          </div>
        </div>
      </div>
      
      {/* Model Notes */}
      <div className="bg-secondary-50 p-4 rounded-lg border border-secondary-200">
        <h4 className="font-medium mb-2">Model Notes & Limitations</h4>
        <ul className="text-sm text-secondary-700 list-disc pl-5 space-y-2">
          <li>
            <strong>Investment Returns:</strong> The model uses a log-normal distribution to simulate investment returns.
            Actual market returns may differ significantly from projections.
          </li>
          <li>
            <strong>Tax Assumptions:</strong> For taxable accounts, a simplified 15% tax on annual gains is applied.
            Your actual tax situation may vary based on income, state taxes, and other factors.
          </li>
          <li>
            <strong>Inflation:</strong> The model does not explicitly account for inflation. Consider using inflation-adjusted
            (real) return expectations if you want to see results in today's dollars.
          </li>
          <li>
            <strong>Loan Terms:</strong> The model assumes fixed interest rates and payment amounts throughout the loan term.
            Variable rate loans may behave differently.
          </li>
          <li>
            <strong>Educational Purpose:</strong> This tool is for educational purposes only and should not replace
            personalized financial advice from qualified professionals.
          </li>
        </ul>
      </div>
    </div>
  );
};

export default AssumptionsTab;
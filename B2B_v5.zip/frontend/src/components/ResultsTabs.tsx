import React, { useState } from 'react';
import { CompareResponse, CompareRequest, downloadJson } from '../lib/api';
import SummaryTab from './SummaryTab';
import ChartsTab from './ChartsTab';
import AssumptionsTab from './AssumptionsTab';

interface ResultsTabsProps {
  results: CompareResponse;
  formData: CompareRequest;
}

const ResultsTabs: React.FC<ResultsTabsProps> = ({ results, formData }) => {
  const [activeTab, setActiveTab] = useState<string>('summary');

  const handleDownload = () => {
    const data = {
      inputs: formData,
      results: results
    };
    downloadJson(data, 'tuition-payoff-optimizer-results.json');
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      {/* Tab Navigation */}
      <div className="flex border-b">
        <button
          className={`tab ${activeTab === 'summary' ? 'tab-active' : ''}`}
          onClick={() => setActiveTab('summary')}
        >
          Summary
        </button>
        <button
          className={`tab ${activeTab === 'charts' ? 'tab-active' : ''}`}
          onClick={() => setActiveTab('charts')}
        >
          Charts
        </button>
        <button
          className={`tab ${activeTab === 'assumptions' ? 'tab-active' : ''}`}
          onClick={() => setActiveTab('assumptions')}
        >
          Assumptions
        </button>
        <div className="flex-grow"></div>
        <button
          className="flex items-center px-4 text-primary-600 hover:text-primary-800"
          onClick={handleDownload}
        >
          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Export
        </button>
      </div>

      {/* Tab Content */}
      <div className="p-6">
        {activeTab === 'summary' && <SummaryTab results={results} />}
        {activeTab === 'charts' && <ChartsTab results={results} />}
        {activeTab === 'assumptions' && <AssumptionsTab formData={formData} />}
      </div>
    </div>
  );
};

export default ResultsTabs;
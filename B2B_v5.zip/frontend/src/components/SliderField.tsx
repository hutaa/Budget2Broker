import React from 'react';
import { Control, Controller, FieldError } from 'react-hook-form';

interface SliderFieldProps {
  control: Control<any>;
  name: string;
  label: string;
  min: number;
  max: number;
  step: number;
  valueFormat?: (value: number) => string;
  error?: FieldError;
  helpText?: string;
}

const SliderField: React.FC<SliderFieldProps> = ({
  control,
  name,
  label,
  min,
  max,
  step,
  valueFormat,
  error,
  helpText,
}) => {
  return (
    <div className="input-group">
      <div className="flex justify-between items-center">
        <label htmlFor={name} className="input-label">
          {label}
        </label>
        <Controller
          control={control}
          name={name}
          render={({ field }) => (
            <span className="text-sm font-medium text-primary-700">
              {valueFormat ? valueFormat(field.value) : field.value}
            </span>
          )}
        />
      </div>
      <div className="mt-2">
        <Controller
          control={control}
          name={name}
          render={({ field }) => (
            <input
              type="range"
              id={name}
              min={min}
              max={max}
              step={step}
              className="slider"
              {...field}
              onChange={(e) => field.onChange(parseFloat(e.target.value))}
            />
          )}
        />
      </div>
      {error && <p className="input-error">{error.message}</p>}
      {helpText && <p className="mt-1 text-xs text-secondary-500">{helpText}</p>}
    </div>
  );
};

export default SliderField;
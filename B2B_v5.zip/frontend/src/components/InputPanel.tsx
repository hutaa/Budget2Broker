import React, { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { CompareRequestSchema, CompareRequest, presets } from '../lib/api';
import FormField from './FormField';
import SliderField from './SliderField';

interface InputPanelProps {
  initialData: CompareRequest | null;
  onSubmit: (data: CompareRequest) => void;
  isLoading: boolean;
}

const InputPanel: React.FC<InputPanelProps> = ({ initialData, onSubmit, isLoading }) => {
  const [activeSection, setActiveSection] = useState<string>('loan');
  
  const { control, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<CompareRequest>({
    resolver: zodResolver(CompareRequestSchema),
    defaultValues: initialData || {
      principal: 30000,
      apr_annual: 0.05,
      term_months: 120,
      min_payment: 318.20,
      extra_payment: 200,
      monthly_contribution: 100,
      split_ratio: 0.5,
      start_savings: 5000,
      expected_return_annual: 0.07,
      volatility_annual: 0.15,
      expense_ratio: 0.001,
      tax_mode: 'taxable',
      horizon_years: 10,
      sims: 500
    }
  });

  // Update form when initialData changes
  React.useEffect(() => {
    if (initialData) {
      reset(initialData);
    }
  }, [initialData, reset]);

  // Apply preset configurations
  const applyPreset = (preset: 'conservative' | 'balanced' | 'aggressive') => {
    setValue('expected_return_annual', presets[preset].expected_return_annual);
    setValue('volatility_annual', presets[preset].volatility_annual);
    setValue('expense_ratio', presets[preset].expense_ratio);
  };

  // Calculate minimum payment when principal, APR, or term changes
  const principal = watch('principal');
  const aprAnnual = watch('apr_annual');
  const termMonths = watch('term_months');

  React.useEffect(() => {
    // Simple amortization formula to calculate minimum payment
    const r = aprAnnual / 12;
    let minPayment;
    
    if (aprAnnual < 0.000001) {
      // If interest rate is effectively zero, simple division
      minPayment = principal / termMonths;
    } else {
      // Standard amortization formula
      minPayment = principal * r * Math.pow(1 + r, termMonths) / (Math.pow(1 + r, termMonths) - 1);
    }
    
    setValue('min_payment', parseFloat(minPayment.toFixed(2)));
  }, [principal, aprAnnual, termMonths, setValue]);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Input Parameters</h2>
      
      {/* Section Tabs */}
      <div className="flex border-b mb-6">
        <button
          className={`tab ${activeSection === 'loan' ? 'tab-active' : ''}`}
          onClick={() => setActiveSection('loan')}
        >
          Loan Details
        </button>
        <button
          className={`tab ${activeSection === 'investment' ? 'tab-active' : ''}`}
          onClick={() => setActiveSection('investment')}
        >
          Investment
        </button>
        <button
          className={`tab ${activeSection === 'strategy' ? 'tab-active' : ''}`}
          onClick={() => setActiveSection('strategy')}
        >
          Strategy
        </button>
      </div>
      
      <form onSubmit={handleSubmit(onSubmit)}>
        {/* Loan Details Section */}
        <div className={activeSection === 'loan' ? 'block' : 'hidden'}>
          <FormField
            control={control}
            name="principal"
            label="Loan Principal"
            type="number"
            prefix="$"
            error={errors.principal}
          />
          
          <SliderField
            control={control}
            name="apr_annual"
            label="Annual Interest Rate"
            min={0}
            max={0.15}
            step={0.001}
            valueFormat={(value) => `${(value * 100).toFixed(2)}%`}
            error={errors.apr_annual}
          />
          
          <FormField
            control={control}
            name="term_months"
            label="Loan Term (months)"
            type="number"
            error={errors.term_months}
          />
          
          <FormField
            control={control}
            name="min_payment"
            label="Minimum Monthly Payment"
            type="number"
            prefix="$"
            error={errors.min_payment}
            disabled={true}
            helpText="Calculated based on principal, interest rate, and term"
          />
          
          <FormField
            control={control}
            name="extra_payment"
            label="Extra Monthly Payment Available"
            type="number"
            prefix="$"
            error={errors.extra_payment}
          />
        </div>
        
        {/* Investment Section */}
        <div className={activeSection === 'investment' ? 'block' : 'hidden'}>
          <div className="mb-6">
            <label className="input-label">Investment Preset</label>
            <div className="flex space-x-2 mt-1">
              <button
                type="button"
                className="btn btn-secondary flex-1"
                onClick={() => applyPreset('conservative')}
              >
                Conservative
              </button>
              <button
                type="button"
                className="btn btn-secondary flex-1"
                onClick={() => applyPreset('balanced')}
              >
                Balanced
              </button>
              <button
                type="button"
                className="btn btn-secondary flex-1"
                onClick={() => applyPreset('aggressive')}
              >
                Aggressive
              </button>
            </div>
          </div>
          
          <FormField
            control={control}
            name="start_savings"
            label="Initial Savings/Investment"
            type="number"
            prefix="$"
            error={errors.start_savings}
          />
          
          <FormField
            control={control}
            name="monthly_contribution"
            label="Base Monthly Investment"
            type="number"
            prefix="$"
            error={errors.monthly_contribution}
            helpText="Amount you're already investing monthly (separate from extra payment)"
          />
          
          <SliderField
            control={control}
            name="expected_return_annual"
            label="Expected Annual Return"
            min={0}
            max={0.15}
            step={0.001}
            valueFormat={(value) => `${(value * 100).toFixed(2)}%`}
            error={errors.expected_return_annual}
          />
          
          <SliderField
            control={control}
            name="volatility_annual"
            label="Annual Volatility"
            min={0.01}
            max={0.3}
            step={0.01}
            valueFormat={(value) => `${(value * 100).toFixed(0)}%`}
            error={errors.volatility_annual}
          />
          
          <SliderField
            control={control}
            name="expense_ratio"
            label="Investment Expense Ratio"
            min={0}
            max={0.01}
            step={0.0001}
            valueFormat={(value) => `${(value * 100).toFixed(2)}%`}
            error={errors.expense_ratio}
          />
          
          <div className="input-group">
            <label className="input-label">Tax Treatment</label>
            <Controller
              control={control}
              name="tax_mode"
              render={({ field }) => (
                <div className="flex mt-1">
                  <button
                    type="button"
                    className={`flex-1 py-2 px-4 text-center ${
                      field.value === 'taxable'
                        ? 'bg-primary-100 text-primary-800 font-medium border border-primary-300'
                        : 'bg-white border border-secondary-300 text-secondary-700'
                    } rounded-l-md`}
                    onClick={() => field.onChange('taxable')}
                  >
                    Taxable
                  </button>
                  <button
                    type="button"
                    className={`flex-1 py-2 px-4 text-center ${
                      field.value === 'tax_advantaged'
                        ? 'bg-primary-100 text-primary-800 font-medium border border-primary-300'
                        : 'bg-white border border-secondary-300 text-secondary-700'
                    } rounded-r-md`}
                    onClick={() => field.onChange('tax_advantaged')}
                  >
                    Tax-Advantaged
                  </button>
                </div>
              )}
            />
            {errors.tax_mode && (
              <p className="input-error">{errors.tax_mode.message}</p>
            )}
          </div>
        </div>
        
        {/* Strategy Section */}
        <div className={activeSection === 'strategy' ? 'block' : 'hidden'}>
          <FormField
            control={control}
            name="horizon_years"
            label="Planning Horizon (years)"
            type="number"
            error={errors.horizon_years}
          />
          
          <SliderField
            control={control}
            name="split_ratio"
            label="Split Ratio (Loan vs. Investment)"
            min={0}
            max={1}
            step={0.01}
            valueFormat={(value) => `${(value * 100).toFixed(0)}% to Loan / ${(100 - value * 100).toFixed(0)}% to Investment`}
            error={errors.split_ratio}
          />
          
          <div className="mt-8 bg-secondary-50 p-4 rounded-md border border-secondary-200">
            <h3 className="text-lg font-medium mb-2">Split Ratio Explained</h3>
            <p className="text-sm text-secondary-700 mb-2">
              This controls how you divide your extra monthly payment:
            </p>
            <ul className="text-sm text-secondary-700 list-disc pl-5 space-y-1">
              <li><strong>100% to Loan (1.0):</strong> All extra money goes to paying down your loan faster</li>
              <li><strong>0% to Loan (0.0):</strong> All extra money goes to investments instead</li>
              <li><strong>50% to Loan (0.5):</strong> Split equally between loan payments and investments</li>
            </ul>
          </div>
        </div>
        
        {/* Submit Button - Always visible */}
        <div className="mt-8">
          <button
            type="submit"
            className="btn btn-primary w-full"
            disabled={isLoading}
          >
            {isLoading ? 'Calculating...' : 'Calculate Optimal Strategy'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default InputPanel;
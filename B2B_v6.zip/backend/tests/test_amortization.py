import sys
import os
import pytest
import numpy as np

# Add the parent directory to the path so we can import the app modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.services.amortization import calculate_amortization, calculate_minimum_payment

def test_calculate_minimum_payment():
    """Test the minimum payment calculation"""
    # Test case 1: Standard loan
    principal = 10000
    apr_annual = 0.05
    term_months = 60
    
    min_payment = calculate_minimum_payment(principal, apr_annual, term_months)
    assert round(min_payment, 2) == 188.71
    
    # Test case 2: Zero interest loan
    principal = 10000
    apr_annual = 0
    term_months = 60
    
    min_payment = calculate_minimum_payment(principal, apr_annual, term_months)
    assert min_payment == principal / term_months

def test_calculate_amortization():
    """Test the amortization calculation"""
    # Test case 1: Standard loan with minimum payments
    principal = 10000
    apr_annual = 0.05
    term_months = 60
    payment = 188.71
    
    result = calculate_amortization(principal, apr_annual, term_months, payment)
    
    # Check that loan is paid off in expected term
    assert result["months_to_zero"] == 60
    
    # Check that final balance is close to zero
    assert result["balance_series"][-1]["value"] < 0.01
    
    # Check that total interest is reasonable
    # For a $10,000 loan at 5% for 5 years, total interest should be around $1,322
    assert 1300 < result["total_interest"] < 1350
    
    # Test case 2: Extra payments
    principal = 10000
    apr_annual = 0.05
    term_months = 60
    payment = 188.71
    extra_payment = 100
    
    result = calculate_amortization(principal, apr_annual, term_months, payment, extra_payment)
    
    # Check that loan is paid off earlier with extra payments
    assert result["months_to_zero"] < 60
    
    # Check that total interest is less with extra payments
    assert result["total_interest"] < 1300

def test_amortization_edge_cases():
    """Test edge cases for amortization calculation"""
    # Test case 1: Zero interest loan
    principal = 10000
    apr_annual = 0
    term_months = 60
    payment = principal / term_months
    
    result = calculate_amortization(principal, apr_annual, term_months, payment)
    
    # Check that loan is paid off in expected term
    assert result["months_to_zero"] == 60
    
    # Check that total interest is zero
    assert result["total_interest"] == 0
    
    # Test case 2: Very high interest rate
    principal = 10000
    apr_annual = 0.2  # 20% interest
    term_months = 60
    payment = calculate_minimum_payment(principal, apr_annual, term_months)
    
    result = calculate_amortization(principal, apr_annual, term_months, payment)
    
    # Check that loan is paid off in expected term
    assert result["months_to_zero"] == 60
    
    # Check that total interest is high
    assert result["total_interest"] > 5000
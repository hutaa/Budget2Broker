import numpy as np
from typing import Dict, List, Tuple, Optional
import pandas as pd

def simulate_investment_growth(
    start_amount: float,
    monthly_contribution: float,
    expected_return_annual: float,
    volatility_annual: float,
    expense_ratio: float,
    horizon_months: int,
    tax_mode: str = "taxable",
    sims: int = 500,
    seed: Optional[int] = None
) -> Dict:
    """
    Simulate investment growth using Monte Carlo simulation.
    
    Args:
        start_amount: Initial investment amount
        monthly_contribution: Monthly contribution to investment
        expected_return_annual: Expected annual return (decimal)
        volatility_annual: Annual volatility/standard deviation (decimal)
        expense_ratio: Annual expense ratio (decimal)
        horizon_months: Investment horizon in months
        tax_mode: "taxable" or "tax_advantaged"
        sims: Number of Monte Carlo simulations
        seed: Random seed for reproducibility
    
    Returns:
        Dictionary with simulation results including:
        - final_values: Array of final investment values
        - percentiles: P10, P50, P90 values at horizon
        - median_series: Monthly median value time series
    """
    # Set random seed if provided
    if seed is not None:
        np.random.seed(seed)
    
    # Adjust expected return for expense ratio
    mu_eff = expected_return_annual - expense_ratio
    
    # Convert annual parameters to monthly
    mu_m = (mu_eff - volatility_annual**2 / 2) / 12
    sigma_m = volatility_annual / np.sqrt(12)
    
    # Initialize array to store simulation results
    # Shape: (sims, horizon_months+1) to include initial value
    values = np.zeros((sims, horizon_months + 1))
    values[:, 0] = start_amount
    
    # Run Monte Carlo simulation
    for month in range(1, horizon_months + 1):
        # Generate random returns
        returns = np.random.normal(mu_m, sigma_m, sims)
        
        # Update values with returns and monthly contribution
        values[:, month] = (values[:, month-1] + monthly_contribution) * np.exp(returns)
        
        # Apply tax drag at the end of each year if taxable
        if tax_mode == "taxable" and month % 12 == 0:
            # Calculate gains for the year
            start_of_year = values[:, month-12]
            end_of_year = values[:, month]
            contributions = monthly_contribution * 12
            gains = end_of_year - start_of_year - contributions
            
            # Apply 15% tax on positive gains only
            tax = np.maximum(gains, 0) * 0.15
            values[:, month] -= tax
    
    # Calculate percentiles at horizon
    final_values = values[:, -1]
    p10 = np.percentile(final_values, 10)
    p50 = np.percentile(final_values, 50)
    p90 = np.percentile(final_values, 90)
    
    # Calculate median path for visualization
    median_path = np.median(values, axis=0)
    median_series = [{"month": i, "value": float(median_path[i])} for i in range(horizon_months + 1)]
    
    return {
        "final_values": final_values.tolist(),
        "percentiles": {
            "p10": float(p10),
            "p50": float(p50),
            "p90": float(p90)
        },
        "median_series": median_series
    }

def calculate_breakeven(
    interest_saved: List[float],
    investment_median: List[Dict[str, float]]
) -> Optional[int]:
    """
    Calculate the breakeven month where investment value exceeds interest saved.
    
    Args:
        interest_saved: Cumulative interest saved by month
        investment_median: Median investment value by month
    
    Returns:
        Breakeven month or None if no breakeven within the horizon
    """
    # Ensure lists are of same length
    min_length = min(len(interest_saved), len(investment_median))
    
    for month in range(min_length):
        if investment_median[month]["value"] >= interest_saved[month]:
            return month
    
    return None

def calculate_investment_with_loan_payoff(
    loan_payoff_month: int,
    extra_payment: float,
    start_amount: float,
    monthly_contribution: float,
    expected_return_annual: float,
    volatility_annual: float,
    expense_ratio: float,
    horizon_months: int,
    tax_mode: str = "taxable",
    sims: int = 500,
    seed: Optional[int] = None
) -> Dict:
    """
    Simulate investment growth with increased contributions after loan payoff.
    
    Args:
        loan_payoff_month: Month when loan is paid off
        extra_payment: Extra payment amount that becomes available after loan payoff
        start_amount: Initial investment amount
        monthly_contribution: Initial monthly contribution to investment
        expected_return_annual: Expected annual return (decimal)
        volatility_annual: Annual volatility/standard deviation (decimal)
        expense_ratio: Annual expense ratio (decimal)
        horizon_months: Investment horizon in months
        tax_mode: "taxable" or "tax_advantaged"
        sims: Number of Monte Carlo simulations
        seed: Random seed for reproducibility
    
    Returns:
        Dictionary with simulation results
    """
    # Set random seed if provided
    if seed is not None:
        np.random.seed(seed)
    
    # Adjust expected return for expense ratio
    mu_eff = expected_return_annual - expense_ratio
    
    # Convert annual parameters to monthly
    mu_m = (mu_eff - volatility_annual**2 / 2) / 12
    sigma_m = volatility_annual / np.sqrt(12)
    
    # Initialize array to store simulation results
    values = np.zeros((sims, horizon_months + 1))
    values[:, 0] = start_amount
    
    # Run Monte Carlo simulation
    for month in range(1, horizon_months + 1):
        # Determine monthly contribution based on loan payoff status
        if month > loan_payoff_month:
            current_contribution = monthly_contribution + extra_payment
        else:
            current_contribution = monthly_contribution
        
        # Generate random returns
        returns = np.random.normal(mu_m, sigma_m, sims)
        
        # Update values with returns and monthly contribution
        values[:, month] = (values[:, month-1] + current_contribution) * np.exp(returns)
        
        # Apply tax drag at the end of each year if taxable
        if tax_mode == "taxable" and month % 12 == 0:
            # Calculate gains for the year
            start_of_year = values[:, month-12]
            end_of_year = values[:, month]
            
            # Calculate contributions for the year (may vary due to loan payoff)
            if month - 12 < loan_payoff_month < month:
                # Mixed year with loan payoff
                months_before_payoff = loan_payoff_month - (month - 12)
                months_after_payoff = 12 - months_before_payoff
                contributions = (monthly_contribution * months_before_payoff) + \
                               ((monthly_contribution + extra_payment) * months_after_payoff)
            elif month <= loan_payoff_month:
                # Year before loan payoff
                contributions = monthly_contribution * 12
            else:
                # Year after loan payoff
                contributions = (monthly_contribution + extra_payment) * 12
            
            gains = end_of_year - start_of_year - contributions
            
            # Apply 15% tax on positive gains only
            tax = np.maximum(gains, 0) * 0.15
            values[:, month] -= tax
    
    # Calculate percentiles at horizon
    final_values = values[:, -1]
    p10 = np.percentile(final_values, 10)
    p50 = np.percentile(final_values, 50)
    p90 = np.percentile(final_values, 90)
    
    # Calculate median path for visualization
    median_path = np.median(values, axis=0)
    median_series = [{"month": i, "value": float(median_path[i])} for i in range(horizon_months + 1)]
    
    return {
        "final_values": final_values.tolist(),
        "percentiles": {
            "p10": float(p10),
            "p50": float(p50),
            "p90": float(p90)
        },
        "median_series": median_series
    }
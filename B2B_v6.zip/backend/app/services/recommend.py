import numpy as np
from typing import Dict, List, Optional, Tuple, Literal
from datetime import date
from app.services.amortization import calculate_amortization, calculate_minimum_payment
from app.services.invest_sim import simulate_investment_growth, calculate_breakeven, calculate_investment_with_loan_payoff

def compare_strategies(
    principal: float,
    apr_annual: float,
    term_months: int,
    min_payment: float,
    extra_payment: float,
    monthly_contribution: float,
    split_ratio: float,
    start_savings: float,
    expected_return_annual: float,
    volatility_annual: float,
    expense_ratio: float,
    tax_mode: str,
    horizon_years: int,
    sims: int = 500,
    seed: Optional[int] = None
) -> Dict:
    """
    Compare different debt repayment and investment strategies.
    
    Args:
        principal: Initial loan amount
        apr_annual: Annual interest rate (decimal)
        term_months: Original loan term in months
        min_payment: Minimum monthly payment amount
        extra_payment: Additional available monthly amount
        monthly_contribution: Base monthly investment contribution
        split_ratio: Portion of extra payment to put toward loan (0-1)
        start_savings: Initial investment amount
        expected_return_annual: Expected annual return (decimal)
        volatility_annual: Annual volatility/standard deviation (decimal)
        expense_ratio: Annual expense ratio (decimal)
        tax_mode: "taxable" or "tax_advantaged"
        horizon_years: Investment horizon in years
        sims: Number of Monte Carlo simulations
        seed: Random seed for reproducibility
    
    Returns:
        Dictionary with comparison results for different strategies
    """
    horizon_months = horizon_years * 12
    
    # Strategy 1: Minimum payments only (baseline)
    min_only = calculate_amortization(
        principal=principal,
        apr_annual=apr_annual,
        term_months=term_months,
        payment=min_payment
    )
    
    # Strategy 2: Pay more (all extra to loan)
    pay_more = calculate_amortization(
        principal=principal,
        apr_annual=apr_annual,
        term_months=term_months,
        payment=min_payment,
        extra_payment=extra_payment
    )
    
    # Strategy 3: Invest more (minimum to loan, all extra to investments)
    invest_more = calculate_amortization(
        principal=principal,
        apr_annual=apr_annual,
        term_months=term_months,
        payment=min_payment
    )
    
    # Strategy 4: Split (portion of extra to loan, rest to investments)
    loan_portion = extra_payment * split_ratio
    investment_portion = extra_payment * (1 - split_ratio)
    
    split = calculate_amortization(
        principal=principal,
        apr_annual=apr_annual,
        term_months=term_months,
        payment=min_payment,
        extra_payment=loan_portion
    )
    
    # Calculate interest saved for each strategy compared to minimum payments
    pay_more_interest_saved = min_only["total_interest"] - pay_more["total_interest"]
    split_interest_saved = min_only["total_interest"] - split["total_interest"]
    
    # Simulate investment growth for each strategy
    
    # Strategy 2: Pay more - invest after loan is paid off
    if pay_more["months_to_zero"] is not None and pay_more["months_to_zero"] < horizon_months:
        pay_more_invest = calculate_investment_with_loan_payoff(
            loan_payoff_month=pay_more["months_to_zero"],
            extra_payment=min_payment + extra_payment,  # Full payment becomes available
            start_amount=start_savings,
            monthly_contribution=monthly_contribution,
            expected_return_annual=expected_return_annual,
            volatility_annual=volatility_annual,
            expense_ratio=expense_ratio,
            horizon_months=horizon_months,
            tax_mode=tax_mode,
            sims=sims,
            seed=seed
        )
    else:
        # If loan is not paid off within horizon, just simulate regular investments
        pay_more_invest = simulate_investment_growth(
            start_amount=start_savings,
            monthly_contribution=monthly_contribution,
            expected_return_annual=expected_return_annual,
            volatility_annual=volatility_annual,
            expense_ratio=expense_ratio,
            horizon_months=horizon_months,
            tax_mode=tax_mode,
            sims=sims,
            seed=seed
        )
    
    # Strategy 3: Invest more
    invest_more_invest = simulate_investment_growth(
        start_amount=start_savings,
        monthly_contribution=monthly_contribution + extra_payment,
        expected_return_annual=expected_return_annual,
        volatility_annual=volatility_annual,
        expense_ratio=expense_ratio,
        horizon_months=horizon_months,
        tax_mode=tax_mode,
        sims=sims,
        seed=seed
    )
    
    # Strategy 4: Split
    if split["months_to_zero"] is not None and split["months_to_zero"] < horizon_months:
        split_invest = calculate_investment_with_loan_payoff(
            loan_payoff_month=split["months_to_zero"],
            extra_payment=min_payment + loan_portion,  # Loan payment becomes available after payoff
            start_amount=start_savings,
            monthly_contribution=monthly_contribution + investment_portion,
            expected_return_annual=expected_return_annual,
            volatility_annual=volatility_annual,
            expense_ratio=expense_ratio,
            horizon_months=horizon_months,
            tax_mode=tax_mode,
            sims=sims,
            seed=seed
        )
    else:
        # If loan is not paid off within horizon, just simulate regular investments
        split_invest = simulate_investment_growth(
            start_amount=start_savings,
            monthly_contribution=monthly_contribution + investment_portion,
            expected_return_annual=expected_return_annual,
            volatility_annual=volatility_annual,
            expense_ratio=expense_ratio,
            horizon_months=horizon_months,
            tax_mode=tax_mode,
            sims=sims,
            seed=seed
        )
    
    # Calculate breakeven points
    # For invest_more vs pay_more, we compare investment growth to interest saved
    
    # Create cumulative interest saved series for pay_more
    cum_interest_saved_pay_more = []
    monthly_interest_saved = pay_more_interest_saved / pay_more["months_to_zero"] if pay_more["months_to_zero"] else 0
    
    for month in range(horizon_months + 1):
        if month == 0:
            cum_interest_saved_pay_more.append(0)
        else:
            cum_interest_saved_pay_more.append(min(month * monthly_interest_saved, pay_more_interest_saved))
    
    # Calculate breakeven month
    breakeven_month = calculate_breakeven(
        interest_saved=cum_interest_saved_pay_more,
        investment_median=invest_more_invest["median_series"]
    )
    
    # Prepare strategy results
    strategies = {
        "pay_more": {
            "months_to_zero": pay_more["months_to_zero"],
            "payoff_date": pay_more["payoff_date"],
            "total_interest": pay_more["total_interest"],
            "interest_saved_vs_min": pay_more_interest_saved,
            "invested_value_p10": pay_more_invest["percentiles"]["p10"],
            "invested_value_p50": pay_more_invest["percentiles"]["p50"],
            "invested_value_p90": pay_more_invest["percentiles"]["p90"],
            "loan_balance": pay_more["balance_series"],
            "invest_median": pay_more_invest["median_series"],
            "notes": "Prioritizes debt payoff before investing more aggressively."
        },
        "invest_more": {
            "months_to_zero": invest_more["months_to_zero"],
            "payoff_date": invest_more["payoff_date"],
            "total_interest": invest_more["total_interest"],
            "interest_saved_vs_min": 0,  # No extra payments to loan
            "invested_value_p10": invest_more_invest["percentiles"]["p10"],
            "invested_value_p50": invest_more_invest["percentiles"]["p50"],
            "invested_value_p90": invest_more_invest["percentiles"]["p90"],
            "loan_balance": invest_more["balance_series"],
            "invest_median": invest_more_invest["median_series"],
            "notes": "Maximizes investment while making minimum loan payments."
        },
        "split": {
            "months_to_zero": split["months_to_zero"],
            "payoff_date": split["payoff_date"],
            "total_interest": split["total_interest"],
            "interest_saved_vs_min": split_interest_saved,
            "invested_value_p10": split_invest["percentiles"]["p10"],
            "invested_value_p50": split_invest["percentiles"]["p50"],
            "invested_value_p90": split_invest["percentiles"]["p90"],
            "loan_balance": split["balance_series"],
            "invest_median": split_invest["median_series"],
            "notes": f"Balanced approach with {split_ratio*100:.0f}% of extra payment to loan, {(1-split_ratio)*100:.0f}% to investments."
        }
    }
    
    # Generate recommendation
    recommendation = generate_recommendation(
        apr_annual=apr_annual,
        expected_return_annual=expected_return_annual,
        breakeven_month=breakeven_month,
        strategies=strategies
    )
    
    return {
        "strategies": strategies,
        "recommendation": recommendation
    }

def generate_recommendation(
    apr_annual: float,
    expected_return_annual: float,
    breakeven_month: Optional[int],
    strategies: Dict
) -> Dict:
    """
    Generate a recommendation based on comparison results.
    
    Args:
        apr_annual: Annual interest rate (decimal)
        expected_return_annual: Expected annual return (decimal)
        breakeven_month: Month where investment exceeds interest saved
        strategies: Dictionary with strategy results
    
    Returns:
        Recommendation dictionary
    """
    # Initialize variables
    strategy: Literal["pay_more", "invest_more", "split"] = "split"  # Default to split
    rationale = ""
    
    # Compare loan interest rate to expected investment return
    rate_diff = expected_return_annual - apr_annual
    
    # Rule 1: If loan rate is significantly higher than expected return, prefer paying off loan
    if apr_annual > expected_return_annual + 0.02:
        strategy = "pay_more"
        rationale = (
            f"Your loan interest rate ({apr_annual*100:.1f}%) is significantly higher than "
            f"expected investment returns ({expected_return_annual*100:.1f}%). "
            f"Paying off high-interest debt first provides a guaranteed return equal to your interest rate."
        )
    
    # Rule 2: If expected return is significantly higher than loan rate and breakeven is reasonable
    elif expected_return_annual > apr_annual + 0.02 and breakeven_month is not None and breakeven_month < 24:
        strategy = "invest_more"
        rationale = (
            f"Your expected investment return ({expected_return_annual*100:.1f}%) significantly exceeds "
            f"your loan interest rate ({apr_annual*100:.1f}%). "
            f"Investing more is likely to outperform debt repayment within {breakeven_month} months."
        )
    
    # Rule 3: If rates are similar or breakeven is long, recommend split approach
    else:
        strategy = "split"
        if abs(rate_diff) <= 0.02:
            rationale = (
                f"Your loan interest rate ({apr_annual*100:.1f}%) and expected investment return "
                f"({expected_return_annual*100:.1f}%) are similar. "
                f"A balanced approach gives you both debt reduction and investment growth."
            )
        else:
            rationale = (
                f"While your expected investment return ({expected_return_annual*100:.1f}%) differs from "
                f"your loan interest rate ({apr_annual*100:.1f}%), the breakeven timeline is long or uncertain. "
                f"A balanced approach manages risk while working toward both goals."
            )
    
    return {
        "strategy": strategy,
        "rationale": rationale,
        "breakeven_month": breakeven_month
    }

def optimize_split_ratio(
    principal: float,
    apr_annual: float,
    term_months: int,
    min_payment: float,
    extra_payment: float,
    monthly_contribution: float,
    start_savings: float,
    expected_return_annual: float,
    volatility_annual: float,
    expense_ratio: float,
    tax_mode: str,
    horizon_years: int,
    target_payoff_months: Optional[int] = None,
    min_cash_buffer: Optional[float] = None,
    sims: int = 500,
    seed: Optional[int] = None
) -> Dict:
    """
    Optimize the split ratio between extra loan payments and investments.
    
    Args:
        principal: Initial loan amount
        apr_annual: Annual interest rate (decimal)
        term_months: Original loan term in months
        min_payment: Minimum monthly payment amount
        extra_payment: Additional available monthly amount
        monthly_contribution: Base monthly investment contribution
        start_savings: Initial investment amount
        expected_return_annual: Expected annual return (decimal)
        volatility_annual: Annual volatility/standard deviation (decimal)
        expense_ratio: Annual expense ratio (decimal)
        tax_mode: "taxable" or "tax_advantaged"
        horizon_years: Investment horizon in years
        target_payoff_months: Target months to pay off loan (optional)
        min_cash_buffer: Minimum cash buffer to maintain (optional)
        sims: Number of Monte Carlo simulations
        seed: Random seed for reproducibility
    
    Returns:
        Dictionary with optimization results
    """
    # Define objective function to maximize
    def objective_function(split_ratio: float) -> float:
        # Get comparison results for this split ratio
        results = compare_strategies(
            principal=principal,
            apr_annual=apr_annual,
            term_months=term_months,
            min_payment=min_payment,
            extra_payment=extra_payment,
            monthly_contribution=monthly_contribution,
            split_ratio=split_ratio,
            start_savings=start_savings,
            expected_return_annual=expected_return_annual,
            volatility_annual=volatility_annual,
            expense_ratio=expense_ratio,
            tax_mode=tax_mode,
            horizon_years=horizon_years,
            sims=sims,
            seed=seed
        )
        
        # Extract metrics
        split_strategy = results["strategies"]["split"]
        
        # Calculate objective value (to be maximized)
        # Base objective: final median investment value
        objective = split_strategy["invested_value_p50"]
        
        # Apply penalties for constraint violations
        
        # Penalty for not meeting target payoff months
        if target_payoff_months is not None and (
            split_strategy["months_to_zero"] is None or 
            split_strategy["months_to_zero"] > target_payoff_months
        ):
            # Severe penalty for missing target
            objective -= 100000
        
        # Penalty for insufficient cash buffer
        if min_cash_buffer is not None:
            # Check if investment value ever drops below buffer
            for point in split_strategy["invest_median"]:
                if point["value"] < min_cash_buffer:
                    # Penalty proportional to shortfall
                    objective -= (min_cash_buffer - point["value"]) * 10
                    break
        
        return objective
    
    # Try different split ratios to find optimal value
    split_ratios = np.linspace(0, 1, 21)  # 0, 0.05, 0.1, ..., 0.95, 1.0
    best_objective = float('-inf')
    best_split_ratio = 0.5  # Default
    best_results = None
    
    for ratio in split_ratios:
        results = compare_strategies(
            principal=principal,
            apr_annual=apr_annual,
            term_months=term_months,
            min_payment=min_payment,
            extra_payment=extra_payment,
            monthly_contribution=monthly_contribution,
            split_ratio=ratio,
            start_savings=start_savings,
            expected_return_annual=expected_return_annual,
            volatility_annual=volatility_annual,
            expense_ratio=expense_ratio,
            tax_mode=tax_mode,
            horizon_years=horizon_years,
            sims=sims,
            seed=seed
        )
        
        # Calculate objective value
        objective = objective_function(ratio)
        
        if objective > best_objective:
            best_objective = objective
            best_split_ratio = ratio
            best_results = results
    
    # Perform sensitivity analysis
    sensitivity = []
    key_params = [
        {"name": "apr_annual", "delta": 0.01},
        {"name": "expected_return_annual", "delta": 0.01},
        {"name": "volatility_annual", "delta": 0.05}
    ]
    
    base_recommendation = best_results["recommendation"]["strategy"]
    
    for param in key_params:
        # Create a copy of the base parameters
        param_value = locals()[param["name"]]
        
        # Test with parameter increased by delta
        locals_copy = locals().copy()
        locals_copy[param["name"]] = param_value + param["delta"]
        
        # Get new recommendation
        results_up = compare_strategies(**{k: locals_copy[k] for k in [
            "principal", "apr_annual", "term_months", "min_payment", "extra_payment",
            "monthly_contribution", "split_ratio", "start_savings", "expected_return_annual",
            "volatility_annual", "expense_ratio", "tax_mode", "horizon_years", "sims", "seed"
        ]})
        
        recommendation_changed = results_up["recommendation"]["strategy"] != base_recommendation
        
        sensitivity.append({
            "param": param["name"],
            "delta": param["delta"],
            "recommendation_change": recommendation_changed
        })
    
    return {
        "best_split_ratio": best_split_ratio,
        "objective_value": best_objective,
        "metrics": best_results["strategies"]["split"],
        "sensitivity": sensitivity
    }
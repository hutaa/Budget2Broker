from pydantic import BaseModel, Field, field_validator, model_validator
from typing import List, Optional, Literal
from datetime import date

class CompareRequest(BaseModel):
    """Request model for loan vs investment comparison"""
    principal: float = Field(..., ge=0, description="Loan principal amount")
    apr_annual: float = Field(..., ge=0, le=1, description="Annual interest rate (decimal)")
    term_months: int = Field(..., ge=1, description="Loan term in months")
    min_payment: float = Field(..., ge=0, description="Minimum monthly payment")
    extra_payment: float = Field(..., ge=0, description="Extra payment amount")
    monthly_contribution: float = Field(..., ge=0, description="Monthly investment contribution")
    split_ratio: float = Field(..., ge=0, le=1, description="Ratio to split extra payment between loan and investment")
    start_savings: float = Field(..., ge=0, description="Initial savings/investment amount")
    expected_return_annual: float = Field(..., ge=-0.1, le=0.2, description="Expected annual investment return (decimal)")
    volatility_annual: float = Field(..., gt=0, le=0.5, description="Annual investment volatility (decimal)")
    expense_ratio: float = Field(..., ge=0, le=0.05, description="Investment expense ratio (decimal)")
    tax_mode: Literal["taxable", "tax_advantaged"] = Field(..., description="Tax treatment of investments")
    horizon_years: int = Field(..., ge=1, le=50, description="Investment horizon in years")
    sims: int = Field(500, ge=100, le=5000, description="Number of Monte Carlo simulations")
    seed: Optional[int] = Field(None, description="Random seed for reproducibility")

    @field_validator('min_payment')
    def min_payment_must_cover_interest(cls, v, values):
        """Validate that minimum payment covers at least interest"""
        if 'principal' in values.data and 'apr_annual' in values.data:
            min_interest = values.data['principal'] * values.data['apr_annual'] / 12
            if v < min_interest:
                raise ValueError(f"Minimum payment must cover at least monthly interest (${min_interest:.2f})")
        return v

    @model_validator(mode='after')
    def validate_model(self):
        """Additional model validation"""
        # Check if minimum payment is sufficient to pay off loan within term
        r = self.apr_annual / 12
        min_payment_required = self.principal * r * (1 + r) ** self.term_months / ((1 + r) ** self.term_months - 1)
        
        if self.min_payment < min_payment_required:
            raise ValueError(
                f"Minimum payment (${self.min_payment:.2f}) is insufficient to pay off loan within term. "
                f"Required minimum: ${min_payment_required:.2f}"
            )
        
        return self

class OptimizeRequest(CompareRequest):
    """Request model for optimization with additional parameters"""
    target_payoff_months: Optional[int] = Field(None, ge=1, le=600, description="Target months to pay off loan")
    min_cash_buffer: Optional[float] = Field(None, ge=0, description="Minimum cash buffer to maintain")
    # Remove split_ratio as it will be optimized
    split_ratio: Optional[float] = None

class PredictSplitRequest(BaseModel):
    """Request model for ML prediction of optimal split ratio"""
    # Same as CompareRequest but without split_ratio
    principal: float = Field(..., ge=0)
    apr_annual: float = Field(..., ge=0, le=1)
    term_months: int = Field(..., ge=1)
    min_payment: float = Field(..., ge=0)
    extra_payment: float = Field(..., ge=0)
    monthly_contribution: float = Field(..., ge=0)
    start_savings: float = Field(..., ge=0)
    expected_return_annual: float = Field(..., ge=-0.1, le=0.2)
    volatility_annual: float = Field(..., gt=0, le=0.5)
    expense_ratio: float = Field(..., ge=0, le=0.05)
    tax_mode: Literal["taxable", "tax_advantaged"]
    horizon_years: int = Field(..., ge=1, le=50)

class TimeSeriesPoint(BaseModel):
    """Data point for time series"""
    month: int
    value: float

class StrategyResult(BaseModel):
    """Results for a specific strategy"""
    months_to_zero: Optional[int] = None
    payoff_date: Optional[str] = None
    total_interest: float
    interest_saved_vs_min: float
    invested_value_p10: float
    invested_value_p50: float
    invested_value_p90: float
    loan_balance: List[TimeSeriesPoint]
    invest_median: List[TimeSeriesPoint]
    notes: str

class Recommendation(BaseModel):
    """Recommendation model"""
    strategy: Literal["pay_more", "invest_more", "split"]
    rationale: str
    breakeven_month: Optional[int] = None

class CompareResponse(BaseModel):
    """Response model for comparison results"""
    strategies: dict[Literal["pay_more", "invest_more", "split"], StrategyResult]
    recommendation: Recommendation

class SensitivityPoint(BaseModel):
    """Sensitivity analysis point"""
    param: str
    delta: float
    recommendation_change: bool

class OptimizeResponse(BaseModel):
    """Response model for optimization results"""
    best_split_ratio: float
    objective_value: float
    metrics: StrategyResult
    sensitivity: List[SensitivityPoint]

class FeatureImportance(BaseModel):
    """Feature importance for ML model"""
    name: str
    importance: float

class PredictSplitResponse(BaseModel):
    """Response model for ML prediction"""
    predicted_split: float
    confidence: float
    top_features: List[FeatureImportance]

class ExampleResponse(BaseModel):
    """Example request/response for frontend use"""
    request: CompareRequest
    response: CompareResponse
# Tuition Payoff Optimizer

A full-stack web application that helps students compare paying extra on student loans versus investing the same money, then recommends a strategy with clear explanations and charts.

## Overview

Tuition Payoff Optimizer is an educational tool designed to help users make informed decisions about their student loan repayment strategy. The application compares different approaches:

1. **Pay More on Loan**: Allocate extra money to pay down the loan faster
2. **Invest More**: Make minimum loan payments and invest the extra money
3. **Split Approach**: Divide extra money between loan payments and investments

Based on the user's specific financial situation, the application recommends the most advantageous strategy and provides detailed visualizations to explain the reasoning.

## Features

- **Interactive Input Form**: Enter loan details, investment parameters, and strategy preferences
- **Personalized Recommendations**: Get a tailored strategy based on your specific financial situation
- **Visual Comparisons**: See charts comparing loan balance reduction vs. investment growth
- **Monte Carlo Simulations**: Investment projections account for market volatility
- **Breakeven Analysis**: Identify when investment returns might exceed interest savings
- **Educational Content**: Learn about the trade-offs between debt repayment and investing
- **Export Results**: Download your analysis as JSON for future reference

## Technology Stack

### Backend
- **FastAPI**: High-performance Python web framework
- **Pydantic**: Data validation and settings management
- **NumPy**: Scientific computing for financial calculations
- **scikit-learn**: Machine learning for strategy optimization
- **Uvicorn**: ASGI server for production deployment

### Frontend
- **React**: UI component library
- **TypeScript**: Type-safe JavaScript
- **Vite**: Next-generation frontend tooling
- **TailwindCSS**: Utility-first CSS framework
- **Recharts**: Composable charting library
- **React Hook Form**: Form validation and handling
- **Zod**: Schema validation

### DevOps
- **Docker**: Containerization for consistent environments
- **Docker Compose**: Multi-container orchestration
- **Nginx**: Web server for the frontend

## Getting Started

### Prerequisites
- Docker and Docker Compose
- Node.js 18+ (for local development)
- Python 3.11+ (for local development)

### Running with Docker Compose

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/tuition-payoff-optimizer.git
   cd tuition-payoff-optimizer
   ```

2. Start the application:
   ```bash
   docker-compose up -d
   ```

3. Access the application at http://localhost

### Local Development

#### Backend

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run the development server:
   ```bash
   uvicorn app.main:app --reload
   ```

5. The API will be available at http://localhost:8000

#### Frontend

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. The frontend will be available at http://localhost:5173

## API Documentation

When the backend is running, you can access the API documentation at:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Key Endpoints

- `GET /health`: Health check endpoint
- `GET /api/example`: Get example request/response data
- `POST /api/compare`: Compare different loan repayment vs. investment strategies
- `POST /api/optimize`: Find the optimal split ratio for your situation
- `POST /api/predict_split`: Use ML to predict the best split ratio

## Disclaimer

This application is for educational purposes only and does not constitute financial advice. The projections are based on mathematical models and assumptions that may not reflect actual market conditions or individual circumstances. Always consult with a qualified financial professional before making important financial decisions.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
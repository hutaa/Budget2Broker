import re

# Read the original file
with open('investment-knowledge.html', 'r') as file:
    content = file.read()

# Add the Instagram Reels tab to the hub-tabs section
tabs_pattern = r'(<div class="hub-tab" data-tab="college-guide">.*?</div>)(\s*</div>)'
tabs_replacement = r'\1\n                   <div class="hub-tab" data-tab="instagram-reels">\n                       <i class="fab fa-instagram"></i> Instagram Reels\n                   </div>\2'
content = re.sub(tabs_pattern, tabs_replacement, content, flags=re.DOTALL)

# Find the position to insert the Instagram Reels tab content
# We'll add it after the last tab-content div
last_tab_pattern = r'(<div class="tab-content" id="college-guide">.*?)(?=\s*<script)'
last_tab_match = re.search(last_tab_pattern, content, re.DOTALL)

if last_tab_match:
    end_position = last_tab_match.end()
    
    # Instagram Reels tab content to insert
    instagram_reels_content = '''
                <div class="tab-content" id="instagram-reels">
                    <div class="instagram-reels-container">
                        <div class="reels-header">
                            <i class="fab fa-instagram"></i>
                            <h2 class="reels-title">Investment Tips from Instagram</h2>
                        </div>
                        <p class="reels-description">Learn from financial experts through these curated Instagram reels about investing, saving, and building wealth.</p>
                        
                        <div class="reels-grid">
                            <!-- Investment Strategy Reels -->
                            <div class="reels-category">
                                <h3><i class="fas fa-chess"></i> Investment Strategies</h3>
                                <div class="reels-list">
                                    <div class="reel-card">
                                        <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/C1KhzHJrQAk/" data-instgrm-version="14"></blockquote>
                                    </div>
                                    <div class="reel-card">
                                        <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/C5Ql_BPLlHD/" data-instgrm-version="14"></blockquote>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Stock Market Tips Reels -->
                            <div class="reels-category">
                                <h3><i class="fas fa-chart-line"></i> Stock Market Tips</h3>
                                <div class="reels-list">
                                    <div class="reel-card">
                                        <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/C5Ql_BPLlHD/" data-instgrm-version="14"></blockquote>
                                    </div>
                                    <div class="reel-card">
                                        <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/C4-4IYSL_Hs/" data-instgrm-version="14"></blockquote>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Retirement Planning Reels -->
                            <div class="reels-category">
                                <h3><i class="fas fa-umbrella-beach"></i> Retirement Planning</h3>
                                <div class="reels-list">
                                    <div class="reel-card">
                                        <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/C5NXGgKL-Hs/" data-instgrm-version="14"></blockquote>
                                    </div>
                                    <div class="reel-card">
                                        <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/reel/C5Ql_BPLlHD/" data-instgrm-version="14"></blockquote>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
'''
    
    # Insert the Instagram Reels tab content
    content = content[:end_position] + instagram_reels_content + content[end_position:]

# Add the Instagram embed script before the closing body tag
if '<script async src="https://www.instagram.com/embed.js"></script>' not in content:
    content = content.replace('</body>', '<script async src="https://www.instagram.com/embed.js"></script>\n</body>')

# Add the CSS link in the head section
if 'instagram-reels.css' not in content:
    content = content.replace('<link rel="stylesheet" href="css/financial-tooltips.css">', 
                             '<link rel="stylesheet" href="css/financial-tooltips.css">\n    <link rel="stylesheet" href="css/instagram-reels.css">')

# Write the modified content back to the file
with open('investment-knowledge.html', 'w') as file:
    file.write(content)

print("Instagram Reels tab added successfully!")
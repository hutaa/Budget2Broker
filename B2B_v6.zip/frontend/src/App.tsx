import { useState, useEffect } from 'react';
import { getExample, compareStrategies, CompareRequest, CompareResponse } from './lib/api';
import InputPanel from './components/InputPanel';
import ResultsTabs from './components/ResultsTabs';
import Header from './components/Header';
import Footer from './components/Footer';
import LoadingOverlay from './components/LoadingOverlay';

function App() {
  const [formData, setFormData] = useState<CompareRequest | null>(null);
  const [results, setResults] = useState<CompareResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Load example data on initial render
  useEffect(() => {
    const loadExample = async () => {
      try {
        setLoading(true);
        const example = await getExample();
        setFormData(example.request);
        setResults(example.response);
      } catch (err) {
        console.error('Error loading example:', err);
        setError('Failed to load example data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    loadExample();
  }, []);

  // Handle form submission
  const handleSubmit = async (data: CompareRequest) => {
    try {
      setLoading(true);
      setError(null);
      const response = await compareStrategies(data);
      setResults(response);
      setFormData(data);
    } catch (err) {
      console.error('Error comparing strategies:', err);
      setError('Failed to calculate results. Please check your inputs and try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">Tuition Payoff Optimizer</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left panel: Inputs */}
          <div className="lg:col-span-1">
            <InputPanel 
              initialData={formData} 
              onSubmit={handleSubmit} 
              isLoading={loading}
            />
          </div>
          
          {/* Right panel: Results */}
          <div className="lg:col-span-2">
            {loading && <LoadingOverlay />}
            {error && (
              <div className="bg-danger-50 border border-danger-200 text-danger-700 px-4 py-3 rounded relative mb-4" role="alert">
                <strong className="font-bold">Error: </strong>
                <span className="block sm:inline">{error}</span>
              </div>
            )}
            {results && !loading && (
              <ResultsTabs results={results} formData={formData!} />
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default App;
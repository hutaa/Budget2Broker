import axios from 'axios';
import { z } from 'zod';

// Base API client
const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Schema definitions
export const TimeSeriesPointSchema = z.object({
  month: z.number(),
  value: z.number(),
});

export const StrategyResultSchema = z.object({
  months_to_zero: z.number().nullable(),
  payoff_date: z.string().nullable(),
  total_interest: z.number(),
  interest_saved_vs_min: z.number(),
  invested_value_p10: z.number(),
  invested_value_p50: z.number(),
  invested_value_p90: z.number(),
  loan_balance: z.array(TimeSeriesPointSchema),
  invest_median: z.array(TimeSeriesPointSchema),
  notes: z.string(),
});

export const RecommendationSchema = z.object({
  strategy: z.enum(['pay_more', 'invest_more', 'split']),
  rationale: z.string(),
  breakeven_month: z.number().nullable(),
});

export const CompareResponseSchema = z.object({
  strategies: z.object({
    pay_more: StrategyResultSchema,
    invest_more: StrategyResultSchema,
    split: StrategyResultSchema,
  }),
  recommendation: RecommendationSchema,
});

export const FeatureImportanceSchema = z.object({
  name: z.string(),
  importance: z.number(),
});

export const PredictSplitResponseSchema = z.object({
  predicted_split: z.number(),
  confidence: z.number(),
  top_features: z.array(FeatureImportanceSchema),
});

export const SensitivityPointSchema = z.object({
  param: z.string(),
  delta: z.number(),
  recommendation_change: z.boolean(),
});

export const OptimizeResponseSchema = z.object({
  best_split_ratio: z.number(),
  objective_value: z.number(),
  metrics: StrategyResultSchema,
  sensitivity: z.array(SensitivityPointSchema),
});

// Request schema
export const CompareRequestSchema = z.object({
  principal: z.number().min(0),
  apr_annual: z.number().min(0).max(1),
  term_months: z.number().int().min(1),
  min_payment: z.number().min(0),
  extra_payment: z.number().min(0),
  monthly_contribution: z.number().min(0),
  split_ratio: z.number().min(0).max(1),
  start_savings: z.number().min(0),
  expected_return_annual: z.number().min(-0.1).max(0.2),
  volatility_annual: z.number().min(0).max(0.5),
  expense_ratio: z.number().min(0).max(0.05),
  tax_mode: z.enum(['taxable', 'tax_advantaged']),
  horizon_years: z.number().int().min(1).max(50),
  sims: z.number().int().min(100).max(5000).optional().default(500),
  seed: z.number().int().optional(),
});

export const OptimizeRequestSchema = CompareRequestSchema.extend({
  split_ratio: z.number().min(0).max(1).optional(),
  target_payoff_months: z.number().int().min(1).max(600).optional(),
  min_cash_buffer: z.number().min(0).optional(),
});

export const PredictSplitRequestSchema = CompareRequestSchema.omit({ split_ratio: true });

// Type definitions
export type TimeSeriesPoint = z.infer<typeof TimeSeriesPointSchema>;
export type StrategyResult = z.infer<typeof StrategyResultSchema>;
export type Recommendation = z.infer<typeof RecommendationSchema>;
export type CompareResponse = z.infer<typeof CompareResponseSchema>;
export type FeatureImportance = z.infer<typeof FeatureImportanceSchema>;
export type PredictSplitResponse = z.infer<typeof PredictSplitResponseSchema>;
export type SensitivityPoint = z.infer<typeof SensitivityPointSchema>;
export type OptimizeResponse = z.infer<typeof OptimizeResponseSchema>;
export type CompareRequest = z.infer<typeof CompareRequestSchema>;
export type OptimizeRequest = z.infer<typeof OptimizeRequestSchema>;
export type PredictSplitRequest = z.infer<typeof PredictSplitRequestSchema>;

// API functions
export const getExample = async () => {
  const response = await api.get('/example');
  return {
    request: CompareRequestSchema.parse(response.data.request),
    response: CompareResponseSchema.parse(response.data.response),
  };
};

export const compareStrategies = async (data: CompareRequest): Promise<CompareResponse> => {
  const response = await api.post('/compare', data);
  return CompareResponseSchema.parse(response.data);
};

export const optimizeStrategy = async (data: OptimizeRequest): Promise<OptimizeResponse> => {
  const response = await api.post('/optimize', data);
  return OptimizeResponseSchema.parse(response.data);
};

export const predictSplit = async (data: PredictSplitRequest): Promise<PredictSplitResponse> => {
  const response = await api.post('/predict_split', data);
  return PredictSplitResponseSchema.parse(response.data);
};

// Utility function to download JSON
export const downloadJson = (data: any, filename: string = 'data.json') => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

// Preset configurations
export const presets = {
  conservative: {
    expected_return_annual: 0.05,
    volatility_annual: 0.10,
    expense_ratio: 0.0005,
  },
  balanced: {
    expected_return_annual: 0.07,
    volatility_annual: 0.15,
    expense_ratio: 0.001,
  },
  aggressive: {
    expected_return_annual: 0.09,
    volatility_annual: 0.20,
    expense_ratio: 0.002,
  },
};

export default api;
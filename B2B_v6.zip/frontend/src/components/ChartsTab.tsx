import React from 'react';
import { CompareResponse } from '../lib/api';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  Label
} from 'recharts';

interface ChartsTabProps {
  results: CompareResponse;
}

const ChartsTab: React.FC<ChartsTabProps> = ({ results }) => {
  const { strategies, recommendation } = results;
  
  // Format currency for tooltip and axis
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  // Format date for x-axis
  const formatDate = (month: number) => {
    const date = new Date();
    date.setMonth(date.getMonth() + month);
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  };
  
  // Prepare loan balance data for chart
  const loanBalanceData = strategies[recommendation.strategy].loan_balance.map(point => ({
    month: point.month,
    value: point.value,
    date: formatDate(point.month)
  }));
  
  // Prepare investment data for chart
  const investmentData = strategies[recommendation.strategy].invest_median.map(point => ({
    month: point.month,
    value: point.value,
    date: formatDate(point.month)
  }));
  
  // Combine data for comparison chart
  const combinedData = loanBalanceData.map(point => {
    const investPoint = investmentData.find(ip => ip.month === point.month);
    return {
      month: point.month,
      date: point.date,
      loanBalance: point.value,
      investmentValue: investPoint ? investPoint.value : 0
    };
  });
  
  // Find max value for chart scaling
  const maxLoanValue = Math.max(...loanBalanceData.map(d => d.value));
  const maxInvestValue = Math.max(...investmentData.map(d => d.value));
  const maxValue = Math.max(maxLoanValue, maxInvestValue) * 1.1; // Add 10% margin
  
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Loan Balance vs. Investment Growth</h3>
      
      {/* Combined Chart */}
      <div className="bg-white p-4 rounded-lg border border-secondary-200 mb-8">
        <ResponsiveContainer width="100%" height={400}>
          <LineChart
            data={combinedData}
            margin={{ top: 20, right: 30, left: 20, bottom: 50 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date" 
              tick={{ fontSize: 12 }}
              interval={Math.floor(combinedData.length / 6)}
              angle={-45}
              textAnchor="end"
            />
            <YAxis 
              tickFormatter={formatCurrency}
              domain={[0, maxValue]}
            />
            <Tooltip 
              formatter={(value: number) => formatCurrency(value)}
              labelFormatter={(label) => `Date: ${label}`}
            />
            <Legend verticalAlign="top" height={36} />
            <Line
              type="monotone"
              dataKey="loanBalance"
              name="Loan Balance"
              stroke="#ef4444"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 6 }}
            />
            <Line
              type="monotone"
              dataKey="investmentValue"
              name="Investment Value"
              stroke="#10b981"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 6 }}
            />
            
            {/* Breakeven Point */}
            {recommendation.breakeven_month && (
              <ReferenceLine
                x={formatDate(recommendation.breakeven_month)}
                stroke="#6366f1"
                strokeDasharray="3 3"
                strokeWidth={2}
              >
                <Label
                  value="Breakeven Point"
                  position="insideBottomRight"
                  offset={10}
                  fill="#6366f1"
                  fontSize={12}
                />
              </ReferenceLine>
            )}
          </LineChart>
        </ResponsiveContainer>
        <p className="text-sm text-secondary-600 mt-4">
          This chart shows the loan balance decreasing over time compared to the projected growth of your investments.
          {recommendation.breakeven_month && (
            <span> The vertical line marks the breakeven point where investment growth exceeds interest savings.</span>
          )}
        </p>
      </div>
      
      {/* Investment Fan Chart */}
      <h3 className="text-lg font-semibold mb-4">Investment Projection Range</h3>
      <div className="bg-white p-4 rounded-lg border border-secondary-200">
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart
            data={investmentData}
            margin={{ top: 20, right: 30, left: 20, bottom: 50 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date" 
              tick={{ fontSize: 12 }}
              interval={Math.floor(investmentData.length / 6)}
              angle={-45}
              textAnchor="end"
            />
            <YAxis tickFormatter={formatCurrency} />
            <Tooltip 
              formatter={(value: number) => formatCurrency(value)}
              labelFormatter={(label) => `Date: ${label}`}
            />
            <Legend verticalAlign="top" height={36} />
            <Area
              type="monotone"
              dataKey="value"
              name="Investment Value (Median)"
              stroke="#6366f1"
              fill="#6366f1"
              fillOpacity={0.3}
            />
            
            {/* P10 and P90 lines would be added here in a real implementation */}
            {/* For simplicity, we're just showing the median projection */}
          </AreaChart>
        </ResponsiveContainer>
        <div className="flex justify-between mt-4 text-sm">
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 bg-primary-200 mr-1"></span>
            <span className="text-secondary-600">P10 (Pessimistic): {formatCurrency(strategies[recommendation.strategy].invested_value_p10)}</span>
          </div>
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 bg-primary-600 mr-1"></span>
            <span className="text-secondary-600">P50 (Median): {formatCurrency(strategies[recommendation.strategy].invested_value_p50)}</span>
          </div>
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 bg-primary-200 mr-1"></span>
            <span className="text-secondary-600">P90 (Optimistic): {formatCurrency(strategies[recommendation.strategy].invested_value_p90)}</span>
          </div>
        </div>
        <p className="text-sm text-secondary-600 mt-4">
          This chart shows the projected growth of your investments over time. The shaded area represents the range of possible outcomes,
          with the median projection shown as a solid line.
        </p>
      </div>
    </div>
  );
};

export default ChartsTab;
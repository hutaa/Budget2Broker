import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-secondary-800 text-white py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-sm">
              &copy; {new Date().getFullYear()} Tuition Payoff Optimizer
            </p>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-sm text-secondary-400 mb-2">
              <strong>Disclaimer:</strong> For educational purposes only. Not financial advice.
            </p>
            <p className="text-xs text-secondary-500">
              This tool provides estimates based on the information you provide and market assumptions.
              Actual results may vary. Consult a financial professional for personalized advice.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
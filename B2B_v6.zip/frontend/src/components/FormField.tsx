import React from 'react';
import { Control, Controller, FieldError } from 'react-hook-form';

interface FormFieldProps {
  control: Control<any>;
  name: string;
  label: string;
  type?: string;
  prefix?: string;
  suffix?: string;
  error?: FieldError;
  disabled?: boolean;
  helpText?: string;
  min?: number;
  max?: number;
  step?: number;
}

const FormField: React.FC<FormFieldProps> = ({
  control,
  name,
  label,
  type = 'text',
  prefix,
  suffix,
  error,
  disabled = false,
  helpText,
  min,
  max,
  step,
}) => {
  return (
    <div className="input-group">
      <label htmlFor={name} className="input-label">
        {label}
      </label>
      <div className="mt-1 relative rounded-md shadow-sm">
        {prefix && (
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <span className="text-secondary-500 sm:text-sm">{prefix}</span>
          </div>
        )}
        <Controller
          control={control}
          name={name}
          render={({ field }) => (
            <input
              type={type}
              id={name}
              className={`input-field ${
                prefix ? 'pl-7' : ''
              } ${
                suffix ? 'pr-12' : ''
              } ${
                error ? 'border-danger-300 text-danger-900 focus:ring-danger-500 focus:border-danger-500' : ''
              }`}
              disabled={disabled}
              min={min}
              max={max}
              step={step}
              {...field}
              value={field.value ?? ''}
              onChange={(e) => {
                const value = type === 'number' ? 
                  (e.target.value === '' ? '' : parseFloat(e.target.value)) : 
                  e.target.value;
                field.onChange(value);
              }}
            />
          )}
        />
        {suffix && (
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            <span className="text-secondary-500 sm:text-sm">{suffix}</span>
          </div>
        )}
      </div>
      {error && <p className="input-error">{error.message}</p>}
      {helpText && <p className="mt-1 text-xs text-secondary-500">{helpText}</p>}
    </div>
  );
};

export default FormField;
import React from 'react';

const LoadingOverlay: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center p-8">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600 mb-4"></div>
      <p className="text-primary-600 font-medium">Calculating results...</p>
      <p className="text-secondary-500 text-sm mt-2">This may take a few moments</p>
    </div>
  );
};

export default LoadingOverlay;